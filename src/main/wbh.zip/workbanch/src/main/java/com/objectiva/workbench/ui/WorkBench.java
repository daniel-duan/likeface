package com.objectiva.workbench.ui;

import com.objectiva.workbench.ui.component.Container;
import com.objectiva.workbench.ui.component.ToolBarPanel;

import javax.swing.*;
import java.awt.*;

public class WorkBench {

    public JFrame createWindow() {
        JFrame window = new JFrame(UIConstants.TITLE);
        window.setSize(UIConstants.WIDTH, UIConstants.HEIGHT);
        window.setBackground(Color.WHITE);

        Dimension fs = window.getSize();
        if (fs.width > App.SCREEN_WIDTH) {
            fs.width = App.SCREEN_WIDTH;
        }
        if (fs.height > App.SCREEN_HEIGHT) {
            fs.height = App.SCREEN_HEIGHT;
        }

        int x = (int) (App.SCREEN_WIDTH - fs.getWidth()) / 2;
        int y = (int) (App.SCREEN_HEIGHT - fs.getHeight()) / 2;
        window.setLocation(x, y); // 设置窗口居中显示器显示
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        return window;
    }


    public JPanel createMainPanel() {
        JPanel layout = new JPanel(new BorderLayout(), true);
        layout.setBackground(Color.WHITE);

        ToolBarPanel toolBar = new ToolBarPanel();
        layout.add(toolBar, BorderLayout.WEST);

        Container container = Container.instance();
        layout.add(container, BorderLayout.CENTER);

        toolBar.setDefaultActive();
        container.setDefaultPanel();
        return layout;
    }
}
