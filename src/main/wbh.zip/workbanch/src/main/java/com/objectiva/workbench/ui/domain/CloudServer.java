package com.objectiva.workbench.ui.domain;

public class CloudServer {
    private boolean original;
    private String name;
    private String url;

    public CloudServer(String name, String url, boolean original) {
        this.original = original;
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public boolean isOriginal() {
        return original;
    }
}
