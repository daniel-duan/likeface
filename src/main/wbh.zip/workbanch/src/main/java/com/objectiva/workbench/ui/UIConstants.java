package com.objectiva.workbench.ui;

import java.awt.*;

public class UIConstants {
    public static final String TITLE = "1";
    public static final int WIDTH = 1200;
    public static final int HEIGHT = 900;

    public final static Color MAIN_COLOR = Color.decode("#3f51b5");
    public final static Color BTN_ACTIVE_COLOR = Color.decode("#1a237e");
    public final static Color ORANGE_COLOR = Color.decode("#ff5722");
    public final static Color ORANGE_ACTIVE_COLOR = Color.decode("#bf360c");

    public final static Image LOGO = Toolkit.getDefaultToolkit().getImage(App.class.getResource("/icon/logo.png"));
    ;
}
