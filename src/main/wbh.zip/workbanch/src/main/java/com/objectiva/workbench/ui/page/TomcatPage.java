package com.objectiva.workbench.ui.page;

import com.objectiva.workbench.ui.component.Console;
import com.objectiva.workbench.ui.component.OperaButton;
import com.objectiva.workbench.ui.component.OperaTool;

import javax.swing.*;
import java.awt.*;

public class TomcatPage extends JPanel {
    private JButton status;
    private JButton start;
    private JButton stop;
    private JButton restart;
    private JButton log;

    public TomcatPage() {
        super(new BorderLayout());
        init();
    }

    public void init() {
        OperaTool operaTool = new OperaTool(1);

        status = new OperaButton(OperaButton.EMPTY_MAIN, "Status");
        start = new OperaButton(OperaButton.EMPTY_MAIN, "Start");
        stop = new OperaButton(OperaButton.EMPTY_MAIN, "Stop");
        restart = new OperaButton(OperaButton.EMPTY_MAIN, "Restart");
        log = new OperaButton(OperaButton.EMPTY_MAIN, "Tail Log");
        operaTool.addToLine1(status);
        operaTool.addToLine1(start);
        operaTool.addToLine1(stop);
        operaTool.addToLine1(restart);
        operaTool.addToLine1(log);

        JPanel console = new Console();

        this.add(operaTool, BorderLayout.NORTH);
        this.add(console, BorderLayout.CENTER);
    }

    public void bindEvent() {

    }
}
