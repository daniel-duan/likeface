package com.objectiva.workbench.ui.page;

import com.objectiva.workbench.ui.component.Console;
import com.objectiva.workbench.ui.component.OperaButton;
import com.objectiva.workbench.ui.component.OperaTool;

import javax.swing.*;
import java.awt.*;

public class CloudPage extends JPanel {
    private JButton status8787;
    private JButton gor;
    private JButton log;
    private Console console;

    public CloudPage() {
        super();
        init();
    }

    public void init() {
        this.setLayout(new BorderLayout());
        OperaTool operaTool = new OperaTool(1);

        status8787 = new OperaButton(OperaButton.EMPTY_MAIN, "8787 Status");
        gor = new OperaButton(OperaButton.EMPTY_MAIN, "Start Gor");
        log = new OperaButton(OperaButton.EMPTY_MAIN, "Operate Log");
        operaTool.addToLine1(status8787);
        operaTool.addToLine1(gor);
        operaTool.addToLine1(log);

        console = new Console();

        this.add(operaTool, BorderLayout.NORTH);
        this.add(console, BorderLayout.CENTER);
    }
}
