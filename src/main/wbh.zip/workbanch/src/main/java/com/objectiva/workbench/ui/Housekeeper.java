package com.objectiva.workbench.ui;

import com.objectiva.workbench.ui.domain.CloudServer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

/**
 * app 管家
 */
public abstract class Housekeeper {
    private final static String SETTING = "/setting.xml";
    public static String runDir;
    private static boolean init;

    public static void appInit() {
        String path = Housekeeper.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        try {
            path = java.net.URLDecoder.decode(path, StandardCharsets.UTF_8.name());// 转换处理中文及空格
        } catch (Exception e) {
        }
        int last = path.lastIndexOf("/");
        if (last < 0) {
            last = path.lastIndexOf("\\");
        }
        runDir = path.substring(0, last);

        File setting = new File(String.format("%s/%s", runDir, SETTING));
        init = setting.exists();
        if (init) {
            try {
                xmlParse(setting);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean hasInit() {
        return init;
    }

    public static void saveSetting(String loginName, String pwd, String workspace) throws Exception {
        Setting.loginName = loginName;
        Setting.password = pwd;
        Setting.workspace.add(workspace);

        File setting = new File(String.format("%s/%s", runDir, SETTING));
        if (!setting.exists()) {
            setting.createNewFile();
        }
        FileWriter fw = new FileWriter(setting);
        fw.write(fileToXmlString());
        fw.flush();
        fw.close();

        init = true;
    }

    private static void xmlParse(File setting) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(setting);

        System.out.println(document.getElementsByTagName("loginName").getLength());
        Element lnEle = (Element) document.getElementsByTagName("loginName").item(0);
        Element pwdEle = (Element) document.getElementsByTagName("password").item(0);
        Setting.loginName = lnEle.getTextContent();
        Setting.password = pwdEle.getTextContent();

        NodeList dirList = document.getElementsByTagName("directory");
        for (int j = 0; j < dirList.getLength(); j++) {
            Element ele = (Element) dirList.item(j);
            Setting.workspace.add(ele.getTextContent());
        }
        NodeList serList = document.getElementsByTagName("server");
        for (int j = 0; j < serList.getLength(); j++) {
            Element ele = (Element) serList.item(j);
            Element name = (Element) ele.getElementsByTagName("name").item(0);
            Element url = (Element) ele.getElementsByTagName("url").item(0);
            if (!"server name".equals(name.getTextContent())) {
                Setting.servers.add(new CloudServer(name.getTextContent(), url.getTextContent(), false));
            }
        }
    }

    private static String fileToXmlString() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("");
        Element loginName = document.createElement("loginName");
        loginName.setTextContent(Setting.loginName);
        Element password = document.createElement("password");
        password.setTextContent(Setting.password);
        root.appendChild(loginName);
        root.appendChild(password);

        Element workspaces = document.createElement("workspaces");
        Setting.workspace.stream().forEach(w -> {
            Element directory = document.createElement("directory");
            directory.setTextContent(w);
            workspaces.appendChild(directory);
        });
        root.appendChild(workspaces);

        Element serverList = document.createElement("serverList");
        List<CloudServer> list = Setting.servers.stream().filter(cs -> !cs.isOriginal()).collect(Collectors.toList());
        if (list.isEmpty()) {
            list.add(new CloudServer("server name", "server url", false));
        }
        list.forEach(cs -> {
            Element name = document.createElement("name");
            name.setTextContent(cs.getName());
            Element url = document.createElement("url");
            url.setTextContent(cs.getUrl());

            Element server = document.createElement("server");
            server.appendChild(name);
            server.appendChild(url);
            serverList.appendChild(server);
        });
        root.appendChild(serverList);

        document.appendChild(root);
        return xmlFormat(document);
    }

    private static String xmlFormat(Document document) throws Exception {
        TransformerFactory transFactory = TransformerFactory.newInstance();
        transFactory.setAttribute("indent-number", 4);
        Transformer trans = transFactory.newTransformer();
        trans.setOutputProperty("encoding", "UTF-8");
        trans.setOutputProperty(OutputKeys.INDENT, "yes");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        trans.transform(new DOMSource(document), new StreamResult(bos));
        return bos.toString();
    }
}
