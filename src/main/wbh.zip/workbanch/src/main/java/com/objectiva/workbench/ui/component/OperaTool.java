package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.App;
import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;

public class OperaTool extends JPanel {
    private JPanel line1;
    private JPanel line2;
    private JPanel line3;

    public OperaTool(int line) {
        super(new FlowLayout(FlowLayout.LEFT, 0, 0));
        this.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        this.setPreferredSize(new Dimension(UIConstants.WIDTH, (10 + 33 * line)));
        this.setBackground(Color.WHITE);

        if (line >= 1) {
            line1 = newLine();
            this.add(line1);
        }
        if (line >= 2) {
            line2 = newLine();
            this.add(line2);
        }
        if (line >= 3) {
            line3 = newLine();
            this.add(line3);
        }
    }

    private void init() {

    }

    public JPanel newLine() {
        JPanel line = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        line.setPreferredSize(new Dimension(App.SCREEN_WIDTH, 33));
        line.setBackground(Color.WHITE);
        return line;
    }

    public void addToLine1(JComponent comp) {
        line1.add(comp);
    }

    public void addToLine2(JComponent comp) {
        line2.add(comp);
    }

    public void addToLine3(JComponent comp) {
        line3.add(comp);
    }
}
