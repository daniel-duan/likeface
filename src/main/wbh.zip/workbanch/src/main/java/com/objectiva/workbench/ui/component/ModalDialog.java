package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.App;
import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;

public class ModalDialog extends JDialog {
    public ModalDialog(String title, int width, int height) {
        super();

        if (width > App.SCREEN_WIDTH) {
            width = App.SCREEN_WIDTH;
        }
        if (height > App.SCREEN_HEIGHT) {
            height = App.SCREEN_HEIGHT;
        }
        int x = (App.SCREEN_WIDTH - width) / 2;
        int y = (App.SCREEN_HEIGHT - height) / 2;

        this.setSize(width, height);
        this.setLocation(x, y); // 设置窗口居中显示器显示
        this.setLayout(new BorderLayout());
        this.setBackground(Color.WHITE);
        this.setIconImage(UIConstants.LOGO);
        this.setTitle(title);
        this.setModal(true);
    }
}
