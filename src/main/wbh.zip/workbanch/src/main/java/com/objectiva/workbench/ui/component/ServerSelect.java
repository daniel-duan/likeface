package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.Setting;
import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;
import java.awt.*;

public class ServerSelect extends JComboBox {
    public ServerSelect() {
        super();
        init();

        addCloudList();
    }

    private void init() {
        setUI(new BasicComboBoxUI() {
            private JButton arrow;

            @Override
            protected JButton createArrowButton() {
                arrow = new JButton();
                arrow.setRolloverEnabled(true);
                arrow.setBorder(null);
                arrow.setBackground(Color.DARK_GRAY);
                arrow.setOpaque(false);
                arrow.setContentAreaFilled(false);
                return arrow;
            }

            @Override
            protected ComboPopup createPopup() {
                BasicComboPopup popup = (BasicComboPopup) super.createPopup();
                popup.setBackground(Color.yellow);
                popup.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIConstants.MAIN_COLOR));
                return popup;
            }
        });
        setBackground(Color.WHITE);
        setFocusable(true);
        setOpaque(false);
        setMaximumRowCount(20);
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        setRenderer(new MyListCellRenderer());
    }
    
    private void addCloudList() {
        Setting.servers.stream().forEach(cs -> this.addItem(cs.getName()));
    }

    private class MyListCellRenderer implements ListCellRenderer {
        private DefaultListCellRenderer defaultCellRenderer = new DefaultListCellRenderer();

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel renderer = (JLabel) defaultCellRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (isSelected) {
                renderer.setBackground(UIConstants.ORANGE_COLOR);
                renderer.setForeground(Color.WHITE);
            } else {
                renderer.setBackground(null);
            }

            renderer.setHorizontalAlignment(JLabel.LEFT);
            renderer.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));
            // render的宽高
            renderer.setPreferredSize(new Dimension(UIConstants.WIDTH, 36));

            // import set selection background color null
            list.setSelectionBackground(null);
            list.setBorder(null);

            return renderer;
        }
    }
}
