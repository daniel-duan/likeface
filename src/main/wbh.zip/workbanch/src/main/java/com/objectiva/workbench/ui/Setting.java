package com.objectiva.workbench.ui;

import com.objectiva.workbench.ui.domain.CloudServer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public abstract class Setting {
    public static String loginName;
    public static String password;
    public static Set<String> workspace = new HashSet<>();
    public static List<CloudServer> servers = new ArrayList<>();

    static {
        servers.add(new CloudServer("abc", "sdfsdf", true));
        servers.add(new CloudServer("sds", "sdfsdf", true));
    }

    private Setting() {
    }
}
