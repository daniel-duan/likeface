package com.objectiva.workbench.ui.page;

import com.objectiva.workbench.ui.Housekeeper;
import com.objectiva.workbench.ui.Setting;
import com.objectiva.workbench.ui.component.OperaButton;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class SetupPage extends JPanel {
    private JTextField nameText;
    private JTextField pwdText;
    private JTextField spaceText;

    private JButton spaceBtn;
    private JButton saveBtn;

    public SetupPage() {
        super(new BorderLayout());

        init();
        this.spaceBtn.addActionListener(e -> {
            selectWorkspace();
        });
        this.saveBtn.addActionListener(e -> {
            saveSetup();
        });
    }

    private void init() {
        JPanel panel = new JPanel(null);
        panel.setBackground(Color.WHITE);

        int st = 30, ht = 50, lw = 150, eh = 30, tw = 300;
        JLabel nameLabel = new JLabel("Login Name:");
        nameText = new JTextField();
        nameText.setText(Setting.loginName);
        System.out.println(Setting.loginName);

        JLabel pwdLabel = new JLabel("Password:");
        pwdText = new JTextField();
        pwdText.setText(Setting.password);

        JLabel spaceLabel = new JLabel("Local Workspace:");
        spaceBtn = new OperaButton(OperaButton.EMPTY_MAIN, "Select");
        spaceText = new JTextField();
        spaceText.setEditable(false);
        if (Setting.workspace.size() > 0) {
            spaceText.setText(Setting.workspace.iterator().next());
        }

        saveBtn = new OperaButton(OperaButton.FILL_MAIN, "SAVE");

        //位置
        nameLabel.setBounds(st, ht * 1, lw, eh);
        nameText.setBounds(lw + 30, ht * 1, tw, eh);
        pwdLabel.setBounds(st, ht * 2, lw, eh);
        pwdText.setBounds(lw + 30, ht * 2, tw, eh);

        spaceLabel.setBounds(st, ht * 3, lw, eh);
        spaceBtn.setBounds(lw + 30, ht * 3, 60, eh - 1);
        spaceText.setBounds(lw + 100, ht * 3, 500, eh);
        saveBtn.setBounds(650, ht * 4, 100, eh);

        panel.add(nameLabel);
        panel.add(nameText);
        panel.add(pwdLabel);
        panel.add(pwdText);
        panel.add(spaceLabel);
        panel.add(spaceText);
        panel.add(spaceBtn);
        panel.add(saveBtn);

        this.add(panel, BorderLayout.CENTER);
    }

    private void saveSetup() {
        String loginName = nameText.getText();
        String pwd = pwdText.getText();
        String workspace = spaceText.getText();
        JOptionPane.showMessageDialog(null, "提示消息.", "ERROR", JOptionPane.ERROR_MESSAGE);
        try {
            Housekeeper.saveSetting(loginName, pwd, workspace);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void selectWorkspace() {
        JFileChooser spaceSelect = new JFileChooser();
        spaceSelect.setMultiSelectionEnabled(false);
        spaceSelect.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        int result = spaceSelect.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File dir = spaceSelect.getSelectedFile();
            this.spaceText.setText(dir.getAbsolutePath());
        }

    }
}
