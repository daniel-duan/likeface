package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.App;
import com.objectiva.workbench.ui.Housekeeper;
import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;

public class ToolBarPanel extends JPanel {
    private JButton devBtn;
    private JButton tomcatBtn;
    private JButton cloudBtn;
    private JButton setupBtn;

    public ToolBarPanel() {
        super(new BorderLayout(), true);
        this.setPreferredSize(new Dimension(100, UIConstants.HEIGHT));
        this.setBackground(UIConstants.MAIN_COLOR);

        initButton();
        buttonListener();
    }

    private void initButton() {
        this.devBtn = new MenuButton(new ImageIcon(App.class.getResource("/icon/dev.png")), "Developer Center");
        this.tomcatBtn = new MenuButton(new ImageIcon(App.class.getResource("/icon/Tomcat.png")), "Tomcat");
        this.cloudBtn = new MenuButton(new ImageIcon(App.class.getResource("/icon/cloud.png")), "Cloud Server");
        this.setupBtn = new MenuButton(new ImageIcon(App.class.getResource("/icon/set.png")), "Set up");

        JPanel operate = new JPanel(new FlowLayout(0, 0, 0), true);
        operate.setBorder(BorderFactory.createEmptyBorder(50, 0, 0, 0));
        operate.setBackground(UIConstants.MAIN_COLOR);
        operate.add(this.devBtn);
        operate.add(this.tomcatBtn);
        operate.add(this.cloudBtn);

        JPanel setting = new JPanel(new BorderLayout(0, 0), true);
        setting.setBackground(UIConstants.MAIN_COLOR);
        setting.add(this.setupBtn);

        this.add(operate, BorderLayout.CENTER);
        this.add(setting, BorderLayout.SOUTH);
    }

    private void buttonListener() {
        this.setupBtn.addActionListener(e -> {
            if (Housekeeper.hasInit()) {
                buttonActive(this.setupBtn);
                Container.instance().showSetupPanel();
            }
        });

        this.tomcatBtn.addActionListener(e -> {
            if (Housekeeper.hasInit()) {
                buttonActive(this.tomcatBtn);
                Container.instance().showTomcatPanel();
            }
        });

        this.cloudBtn.addActionListener(e -> {
            if (Housekeeper.hasInit()) {
                buttonActive(this.cloudBtn);
                Container.instance().showCloudPanel();
            }
        });

        this.devBtn.addActionListener(e -> {
            if (Housekeeper.hasInit()) {
                buttonActive(this.devBtn);
                Container.instance().showDevPanel();
            }
        });
    }

    private void buttonActive(JButton btn) {
        if (!this.devBtn.isEnabled()) {
            this.devBtn.setEnabled(true);
            this.devBtn.setBackground(UIConstants.MAIN_COLOR);
        }
        if (!this.tomcatBtn.isEnabled()) {
            this.tomcatBtn.setEnabled(true);
            this.tomcatBtn.setBackground(UIConstants.MAIN_COLOR);
        }
        if (!this.cloudBtn.isEnabled()) {
            this.cloudBtn.setEnabled(true);
            this.cloudBtn.setBackground(UIConstants.MAIN_COLOR);
        }
        if (!this.setupBtn.isEnabled()) {
            this.setupBtn.setEnabled(true);
            this.setupBtn.setBackground(UIConstants.MAIN_COLOR);
        }

        btn.setEnabled(false);
        btn.setBackground(UIConstants.BTN_ACTIVE_COLOR);
    }

    public void setDefaultActive() {
        if (Housekeeper.hasInit()) {
            this.buttonActive(this.devBtn);
        } else {
            this.buttonActive(this.setupBtn);
        }
    }
}
