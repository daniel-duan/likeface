package com.objectiva.workbench.ui.page;

import com.objectiva.workbench.ui.component.Console;
import com.objectiva.workbench.ui.component.ModalDialog;
import com.objectiva.workbench.ui.component.OperaButton;
import com.objectiva.workbench.ui.component.OperaTool;
import com.objectiva.workbench.ui.component.ProjectSelect;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DeveloperPage extends JPanel {
    private JButton proBtn;
    private JButton gitBtn;
    private JLabel projectLabel;
    private JLabel gitLabel;

    private JButton changeList;
    private JButton uploaded;
    private JButton clsTrans;
    private JButton jarTrans;

    private JDialog proDialog;
    private JDialog gitDialog;

    private Console console;

    private List<String> localProjects;
    private List<String> gitNumbers;

    public DeveloperPage() {
        super(new BorderLayout());

        init();
        initDialog();
        bindEvent();

        console.startConsole(running -> {
            System.out.println("cloese");
        });
    }

    public void init() {
        OperaTool operaTool = new OperaTool(2);

        proBtn = new OperaButton(OperaButton.FILL_ORANGE, "Project Changes");
        gitBtn = new OperaButton(OperaButton.FILL_ORANGE, "Version Numbers");
        projectLabel = new JLabel("0 items selected");
        projectLabel.setPreferredSize(new Dimension(140, 28));
        gitLabel = new JLabel("0 items entered");
        gitLabel.setPreferredSize(new Dimension(140, 28));

        clsTrans = new OperaButton(OperaButton.EMPTY_ORANGE, "Class Transfer");
        jarTrans = new OperaButton(OperaButton.EMPTY_ORANGE, "Jar Transfer");
        changeList = new OperaButton(OperaButton.EMPTY_ORANGE, "View Change List");
        uploaded = new OperaButton(OperaButton.EMPTY_ORANGE, "View Uploaded");

        operaTool.addToLine1(proBtn);
        operaTool.addToLine1(projectLabel);
        operaTool.addToLine1(gitBtn);
        operaTool.addToLine1(gitLabel);

        operaTool.addToLine2(clsTrans);
        operaTool.addToLine2(jarTrans);
        operaTool.addToLine2(changeList);
        operaTool.addToLine2(uploaded);

        console = new Console();

        this.add(operaTool, BorderLayout.NORTH);
        this.add(console, BorderLayout.CENTER);
    }

    private void bindEvent() {
        this.proBtn.addActionListener(e -> {
            proDialog.setVisible(true);
        });
        this.gitBtn.addActionListener(e -> {
            gitDialog.setVisible(true);
        });
    }

    private void initDialog() {
        this.proDialog = new ModalDialog("Select items to be scanned automatically", 600, 800);
        this.gitDialog = new ModalDialog("Enter the git version number to be scanned automatically", 600, 450);

        ProjectSelect workspace = new ProjectSelect();
        JPanel proSouth = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));
        JButton proSubmit = new OperaButton(OperaButton.FILL_MAIN, "SAVE");
        proSubmit.addActionListener(e -> {
            this.localProjects = workspace.getSelect();
            this.proDialog.setVisible(false);
            projectLabel.setText(String.format("%s items selected", this.localProjects.size()));
        });
        proSouth.setBackground(Color.WHITE);
        proSouth.add(proSubmit);
        this.proDialog.add(workspace, BorderLayout.CENTER);
        this.proDialog.add(proSouth, BorderLayout.SOUTH);

        JTextArea numbers = new JTextArea();
        numbers.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        numbers.setBackground(Color.WHITE);
        JPanel gitSouth = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));
        JButton gitSubmit = new OperaButton(OperaButton.FILL_MAIN, "SAVE");
        gitSubmit.addActionListener(e -> {
            String[] lines = numbers.getText().split("\n");
            this.gitNumbers = Arrays.stream(lines).filter(n -> !"".equals(n.trim())).collect(Collectors.toList());
            this.gitDialog.setVisible(false);
            gitLabel.setText(String.format("%s items entered", this.gitNumbers.size()));
        });
        gitSouth.setBackground(Color.WHITE);
        gitSouth.add(gitSubmit);
        this.gitDialog.add(numbers, BorderLayout.CENTER);
        this.gitDialog.add(gitSouth, BorderLayout.SOUTH);
    }
}
