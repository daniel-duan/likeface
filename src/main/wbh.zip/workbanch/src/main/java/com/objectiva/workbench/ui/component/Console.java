package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.App;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseWheelListener;
import java.util.function.Consumer;

public class Console extends JPanel implements ActionListener {
    private static final int MAX_LINE = 120;

    private boolean running = false;//是否运行中

    private JTextArea textArea;
    private JButton goon;
    private JButton stop;
    private Timer clearTimer;
    private JScrollBar scrollbar;
    private JScrollPane scrollPanel;
    private Consumer<Boolean> stopFun;

    private AdjustmentListener bottomListener;
    private MouseWheelListener scrollListener;

    public Console() {
        super(new BorderLayout());
        this.clearTimer = new Timer(1000, this);
        this.setBackground(Color.WHITE);
        this.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY));
        this.bottomListener = (event) -> scrollbar.setValue(scrollbar.getMaximum());
        this.scrollListener = (event) -> {
            if (event.getWheelRotation() < 0) {
                this.goon.setEnabled(true);
                this.closeSuperTool();
            }
        };

        init();
    }

    public void init() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
        bar.setBackground(Color.WHITE);
        this.goon = new ConsoleButton(new ImageIcon(App.class.getResource("/icon/goon1.png")), new ImageIcon(App.class.getResource("/icon/goon2.png")));
        this.goon.addActionListener(e -> {
            if (this.goon.isEnabled()) {
                this.goon.setEnabled(false);
                scrollbar.setValue(scrollbar.getMaximum());
                this.openSuperTool();
            }
        });

        this.stop = new ConsoleButton(new ImageIcon(App.class.getResource("/icon/stop1.png")), new ImageIcon(App.class.getResource("/icon/stop2.png")));
        this.stop.addActionListener(e -> stopConsole());

        bar.add(this.goon);
        bar.add(this.stop);

        this.textArea = new JTextArea();
        this.textArea.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        this.textArea.setEditable(false);
        this.scrollPanel = new JScrollPane(textArea);
        this.scrollPanel.setBorder(BorderFactory.createEmptyBorder());
        this.scrollbar = this.scrollPanel.getVerticalScrollBar();

        this.add(bar, BorderLayout.NORTH);
        this.add(this.scrollPanel, BorderLayout.CENTER);
    }

    public boolean startConsole(Consumer<Boolean> stopFun) {
        if (running) {
            return false;
        }
        this.running = true;
        this.stop.setEnabled(true);
        this.openSuperTool();
        this.stopFun = stopFun;

        return true;
    }

    public void stopConsole() {
        if (running) {
            this.running = false;
            this.stop.setEnabled(false);
            this.goon.setEnabled(false);
            this.closeSuperTool();
            this.stopFun.accept(running);
            this.stopFun = null;
        }
    }

    public void println(String text) {
        if (running) {
            //超过800行，并且clearTimer已经关闭，则停止输出
            if (textArea.getLineCount() > MAX_LINE && !clearTimer.isRunning()) {
                return;
            }
            textArea.append(text);
            textArea.append("\n");
        }
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        int lines = textArea.getLineCount();
        if (lines > MAX_LINE) {
            try {
                textArea.replaceRange("", 0, textArea.getLineEndOffset(lines - MAX_LINE));
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        }
    }

    private void openSuperTool() {
        this.clearTimer.start();
        this.scrollbar.addAdjustmentListener(bottomListener);
        this.scrollPanel.addMouseWheelListener(scrollListener);
    }
    private void closeSuperTool() {
        this.clearTimer.stop();
        this.scrollPanel.removeMouseWheelListener(this.scrollListener);
        this.scrollbar.removeAdjustmentListener(this.bottomListener);
    }
}
