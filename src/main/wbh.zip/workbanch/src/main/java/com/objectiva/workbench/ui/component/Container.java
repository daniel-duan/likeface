package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.Housekeeper;
import com.objectiva.workbench.ui.UIConstants;
import com.objectiva.workbench.ui.page.CloudPage;
import com.objectiva.workbench.ui.page.DeveloperPage;
import com.objectiva.workbench.ui.page.SetupPage;
import com.objectiva.workbench.ui.page.TomcatPage;

import javax.swing.*;
import java.awt.*;

public class Container extends JPanel {
    private JPanel serverPanel;
    private JPanel center;
    private JPanel tomcatPanel;
    private JPanel cloudPanel;
    private JPanel devPanel;
    private JPanel setupPanel;

    private Container() {
        super(new BorderLayout(), true);
        init();
    }

    public static Container instance() {
        return Inner.instance;
    }

    private static class Inner {
        private static final Container instance = new Container();
    }

    private void init() {
        this.serverPanel = new JPanel(new BorderLayout(), true);
        this.serverPanel.setPreferredSize(new Dimension(UIConstants.WIDTH, 50));
        this.serverPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
        this.serverPanel.setBackground(Color.WHITE);

        JComboBox select = new ServerSelect();
        this.serverPanel.add(select, BorderLayout.CENTER);

        this.center = new JPanel(new BorderLayout());
        this.add(this.serverPanel, BorderLayout.NORTH);
        this.add(this.center, BorderLayout.CENTER);

        //page
        this.tomcatPanel = new TomcatPage();
        this.cloudPanel = new CloudPage();
        this.devPanel = new DeveloperPage();
        this.setupPanel = new SetupPage();
    }

    public void setDefaultPanel() {
        if (Housekeeper.hasInit()) {
            this.showDevPanel();
        } else {
            this.showSetupPanel();
        }
    }

    public void showTomcatPanel() {
        this.panelSwitch(this.tomcatPanel, true);
    }

    public void showCloudPanel() {
        this.panelSwitch(this.cloudPanel, true);
    }

    public void showDevPanel() {
        this.panelSwitch(this.devPanel, true);
    }

    public void showSetupPanel() {
        this.panelSwitch(this.setupPanel, false);
    }

    private void panelSwitch(JPanel show, boolean showServer) {
        this.serverPanel.setVisible(showServer);

        this.center.removeAll();
        this.center.add(show, BorderLayout.CENTER);
        this.updateUI();
    }
}
