package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuButton extends JButton {
    private final String tip;

    public MenuButton(ImageIcon icon, String tip) {
        super(icon);
        this.tip = tip;
        init();
        setUp();
    }

    private void init() {
        this.setBorderPainted(false);
        this.setFocusPainted(false);
        this.setFocusable(true);
        this.setMargin(new Insets(0, 0, 0, 0));
        this.setPreferredSize(new Dimension(100, 60));
        this.setBackground(UIConstants.MAIN_COLOR);
        repaint();
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(UIConstants.BTN_ACTIVE_COLOR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(UIConstants.MAIN_COLOR);
                }
            }
        });
    }

    /**
     * 设置按钮图标：鼠标移过、按压、失效的图标 和设置按钮提示
     */
    private void setUp() {
        if (!tip.equals("")) {
            this.setToolTipText(tip);
        }
    }
}
