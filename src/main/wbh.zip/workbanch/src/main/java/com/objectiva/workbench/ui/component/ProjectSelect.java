package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.Setting;
import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProjectSelect extends JPanel {
    private final ListModel listModel;
    private final JList<String> proList;

    public ProjectSelect() {
        super(new BorderLayout());
        listModel = new DefaultComboBoxModel(getAllProjects());

        this.proList = new JList<>(listModel);
        this.proList.setSelectionModel(new DefaultListSelectionModel() {
            @Override
            public void setSelectionInterval(int idx1, int idx2) {
                if (super.isSelectedIndex(idx1)) {
                    super.removeSelectionInterval(idx1, idx2);
                } else {
                    super.addSelectionInterval(idx1, idx2);
                }
            }
        });
        this.proList.setCellRenderer(new ProjectCheckBox());

        JScrollPane scrollPanel = new JScrollPane(this.proList);
        scrollPanel.setBorder(BorderFactory.createEmptyBorder());
        this.setBackground(Color.WHITE);

        add(scrollPanel, BorderLayout.CENTER);
    }

    public List<String> getSelect() {
        return proList.getSelectedValuesList();
    }

    private String[] getAllProjects() {
        List<String> list = new ArrayList<>();
        Setting.workspace.stream().forEach(ws -> {
            File file = new File(ws);
            if (file.exists() && file.isDirectory()) {
                Arrays.stream(file.listFiles()).filter(f -> f.isDirectory()).forEach(dir -> {
                    list.add(dir.getName());
                });
            }
        });

        return list.toArray(new String[list.size()]);
    }

    public class ProjectCheckBox extends JCheckBox implements ListCellRenderer {
        public ProjectCheckBox() {
            super();
        }

        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            this.setText(value.toString());
            this.setSelected(isSelected);
            setBackground(isSelected ? UIConstants.ORANGE_COLOR : null);
            setForeground(isSelected ? Color.WHITE : Color.BLACK);
            this.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
            // render的宽高
            this.setPreferredSize(new Dimension(520, 30));

            return this;
        }
    }
}
