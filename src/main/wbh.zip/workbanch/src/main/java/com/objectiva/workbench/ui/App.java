package com.objectiva.workbench.ui;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.util.Enumeration;

public class App {
    private static Frame window;
    public static final int SCREEN_WIDTH;
    public static final int SCREEN_HEIGHT;

    static {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        SCREEN_WIDTH = screen.width;
        SCREEN_HEIGHT = screen.height;
        initGlobalFontSetting(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
    }

    public static void main(String[] args) {
        Housekeeper.appInit();

        WorkBench workBench = new WorkBench();
        window = workBench.createWindow();
        window.add(workBench.createMainPanel());
        window.setIconImage(UIConstants.LOGO);
        window.setVisible(true);
    }

    public static void initGlobalFontSetting(Font fnt) {
        FontUIResource fontRes = new FontUIResource(fnt);
        for (Enumeration keys = UIManager.getDefaults().keys(); keys.hasMoreElements(); ) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof FontUIResource) {
                UIManager.put(key, fontRes);
            }
        }
    }
}
