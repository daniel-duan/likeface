package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class OperaButton extends JButton {
    public static final int FILL_MAIN = 1;
    public static final int EMPTY_MAIN = 2;
    public static final int FILL_ORANGE = 3;
    public static final int EMPTY_ORANGE = 4;

    public OperaButton(int type, String text) {
        super(text);
        init();
        Color border, fill, enter, fontOut, fontIn;
        if (type == 1) {
            border = UIConstants.MAIN_COLOR;
            fill = UIConstants.MAIN_COLOR;
            enter = UIConstants.BTN_ACTIVE_COLOR;
            fontOut = Color.WHITE;
            fontIn = Color.WHITE;
        } else if (type == 3){
            border = UIConstants.ORANGE_COLOR;
            fill = UIConstants.ORANGE_COLOR;
            enter = UIConstants.ORANGE_ACTIVE_COLOR;
            fontOut = Color.WHITE;
            fontIn = Color.WHITE;
        } else if (type == 4){
            border = UIConstants.ORANGE_COLOR;
            fill = Color.WHITE;
            enter = UIConstants.ORANGE_COLOR;
            fontOut = Color.BLACK;
            fontIn = Color.WHITE;
        } else{
            border = UIConstants.MAIN_COLOR;
            fill = Color.WHITE;
            enter = UIConstants.MAIN_COLOR;
            fontOut = Color.BLACK;
            fontIn = Color.WHITE;
        }

        this.setBorder(BorderFactory.createLineBorder(border, 1));
        this.setBackground(fill);
        this.setForeground(fontOut);
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(enter);
                setForeground(fontIn);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(fill);
                setForeground(fontOut);
            }
        });
    }

    private void init() {
        this.setFocusPainted(false);
        this.setFocusable(true);
        this.setMargin(new Insets(0, 0, 0, 0));
        this.setPreferredSize(new Dimension(140, 28));
    }
}
