package com.objectiva.workbench.ui.component;

import com.objectiva.workbench.ui.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ConsoleButton extends JButton {
    public ConsoleButton(ImageIcon disable, ImageIcon enable) {
        super(disable);

        //初始化，设置按钮属性：无边，无焦点渲染，无内容区，各边距0
        this.setFocusPainted(false);
        this.setContentAreaFilled(false);
        this.setFocusable(true);
        this.setMargin(new Insets(0, 0, 0, 0));
        this.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));

        this.setIcon(enable);
        this.setDisabledIcon(disable);
        this.setEnabled(false);//默认禁用

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(UIConstants.BTN_ACTIVE_COLOR);
                setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
            }
        });
    }
}
