本地开发
    选择工程
    设置版本号
    查看本地代码（修改的，版本号）
    查看服务器代码（com目录下）
    上传代码（修改的，版本号）
    上传jar包
tomcat
    stop
    start
    restart
    status

云服务器
    查看8787
    gor
    服务器日志
